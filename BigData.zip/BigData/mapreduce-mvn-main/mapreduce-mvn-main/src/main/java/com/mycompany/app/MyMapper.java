package com.mycompany.app;

import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 *
 * @author ajay
 *         Modified by: Nathan Eloe
 * 
 */

public class MyMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

    @Override
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String[] row = value.toString().split("\t");
        String role = row[2];
        String maritalStatus = row[1];
        int sal = Integer.parseInt(row[3]);
        String finalResult = maritalStatus + "\t" + role;
        context.write(new Text(finalResult), new IntWritable(1));
    }

}